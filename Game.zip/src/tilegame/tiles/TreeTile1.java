package tilegame.tiles;

import tilegame.gfx.Assets;

public class TreeTile1 extends Tile {
    public TreeTile1(int id){
        super(Assets.tree[2], id);
    }
}
