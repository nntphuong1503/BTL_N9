package tilegame.tiles;

import tilegame.gfx.Assets;

public class TreeTile extends Tile {
    public TreeTile(int id){
        super(Assets.tree[0], id);
    }
}
