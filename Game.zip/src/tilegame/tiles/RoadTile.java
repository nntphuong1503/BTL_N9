package tilegame.tiles;

import tilegame.gfx.Assets;

public class RoadTile extends Tile{
    public RoadTile(int id){
      super(Assets.road, id);
    }
}
