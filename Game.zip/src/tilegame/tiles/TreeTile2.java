package tilegame.tiles;

import tilegame.gfx.Assets;

public class TreeTile2 extends Tile {
    public TreeTile2(int id){
        super(Assets.tree[2], id);
    }
}
