package tilegame.entity.create;

public interface Move {
    public void move();
}
