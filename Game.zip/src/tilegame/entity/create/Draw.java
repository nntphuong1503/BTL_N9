package tilegame.entity.create;

import java.awt.*;

public interface Draw {
    public void render(Graphics g);
}
