package tilegame.entity.create;

public interface Update {
    public void tick();
}
